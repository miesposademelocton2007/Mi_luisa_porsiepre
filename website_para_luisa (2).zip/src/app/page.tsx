
import React, { useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GalleryVerticalEnd, Heart, Mail } from "lucide-react";
import { motion } from "framer-motion";

export default function WebsiteParaLuisa() {
  const audioRef = useRef(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.play().catch((e) => console.log("Audio play blocked", e));
    }
  }, []);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-8">
      <audio ref={audioRef} src="/audio/Download (21).mp3" autoPlay loop />

      <header className="text-center space-y-2">
        <h1 className="text-4xl font-bold text-pink-600">Para Mi Amor Luisa 💖</h1>
        <p className="text-lg text-gray-600">Nuestra historia, nuestra fe, nuestro amor eterno</p>
      </header>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold flex items-center gap-2 text-rose-500">
          <GalleryVerticalEnd size={24} /> Galería de Recuerdos
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <img src="/photos/WhatsApp Image 2025-05-10 at 19.38.35 (2).jpeg" alt="Luisa y flores" className="rounded-2xl shadow-lg" />
          <img src="/photos/WhatsApp Image 2025-05-10 at 19.39.19 (1).jpeg" alt="Luisa y su amor" className="rounded-2xl shadow-lg" />
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold flex items-center gap-2 text-violet-600">
          <Mail size={24} /> Carta para Luisa
        </h2>
        <Card>
          <CardContent className="p-6 text-gray-800 space-y-4">
            <p>
              Mi querida Luisa, mi niña Lady Bug de miel,
              aunque muchos huirían de un amor tan intenso como el nuestro,
              nosotros sabemos que con Dios todo es posible.
            </p>
            <p>
              Cada día que pasa, te amo más. Nuestro amor está tejido con fe, esperanza
              y la certeza de que lo nuestro es eterno. Dios está en el centro de
              nuestra historia, y por eso nada ni nadie podrá romper lo que Él ha unido.
            </p>
            <p>
              Mi amor por ti es para siempre y cada día florece aún más fuerte.
              Gracias por ser mi inspiración, mi alegría, mi compañera y el regalo más hermoso
              que Dios me ha dado. Te amo con todo mi corazón, hoy y para siempre.
            </p>
            <p className="font-bold text-rose-500 text-xl">Con amor eterno, tu esposo ❤️</p>
          </CardContent>
        </Card>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold flex items-center gap-2 text-sky-500">
          <Heart size={24} /> Nuestro Video
        </h2>
        <video className="w-full rounded-2xl shadow-lg" controls>
          <source src="/video/WhatsApp Video 2025-05-10 at 19.38.34.mp3" type="video/mp4" />
          Tu navegador no soporta el video.
        </video>
      </section>

      <motion.footer 
        className="text-center pt-8 text-sm text-gray-500"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        © 2025 Tu esposo enamorado. Amor eterno para Luisa. Con Dios todo es posible.
      </motion.footer>
    </div>
  );
}
